namespace WildBall.Inputs
{
    public class GlobalStringVars
    {
        #region Input Vars

        public const string HORIZONTAL_AXIS = "Horizontal";
        public const string VERTICAL_AXIS = "Vertical";
        public const string JUMP_BUTTON = "Jump";
        #endregion
    }

}

